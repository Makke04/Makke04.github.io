// Uppgift 9 \\

// Skapa en fil och läs sedan från filen \\

// tips använd fs.readFile('namn_påFilen', function(err, data) för att läsa filen \\