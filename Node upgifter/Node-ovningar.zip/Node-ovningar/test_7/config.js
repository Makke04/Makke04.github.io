function add(num1, num2) {
    console.log(num1 + num2);
}
add(5,5)
exports.module = add