// Uppgift 7 \\

// importera från en fil och kör i terminalen \\

// Du kan inmportera med t.ex. require "const namn_på variabel = require('Sökväg_till fil')"



