// Uppgift 2 \\
// Skriv ut i terminalen "Hej Node" \\

// Skriv koden här under \\ 
"Hej Node"