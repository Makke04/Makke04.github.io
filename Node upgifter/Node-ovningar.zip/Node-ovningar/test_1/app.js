// Uppgift 1 \\
// Skapa ditt första node script \\

// Ladda ner Nodejs från https://nodejs.org/en/ \\

// Installera node på din dator \\

// Öppna terminalen och skriv node --version \\
// Vad skrivs ut i terminalen??? \\
// Skriv ditt svar här: Welcome to Node.js v12.18.3  \\
// vad händer om man skirver node i terminalen och sedan .editor? \\

// Skriv ditt svar här: Entering editor mode(^D to finish, ^C to cancel) \\