// Uppgift 3 \\

// Skapa en variabel som heter "greetins", variabel innhåller en texten "Welcome to backend-side" \\

// Skriv koden här under \\

let greetins = 'Welcome to backend-side'
console.log(greetins)