// Uppgift 5 \\

// Installera ett tilllägg till node \\

// När du installerar ett tillägg skriver du "npm install [namn på tillägget]" ex. npm install express \\

// Först behöver du en package-json fil, Skriv npm init -y \\

// installera ett tilllägg som heter promt-sync \\