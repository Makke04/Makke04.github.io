// Uppgift 4 \\

// Skapa en function som körs två gånger och skriver ut "Doublefun" \\

// Skriv koden här under \\

function Doublefun(){
    console.log("doublefun")
    console.log("doublefun");

}