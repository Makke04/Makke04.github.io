// Uppgift 10 \\

// Skapa en fil med text i, sedan ska du lägga till text i filen \\

// Använd fs.appendFile() för att lägga till text \\